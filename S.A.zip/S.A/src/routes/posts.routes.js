const express = require("express");
const router = express.Router();
//importar o controller depois

router.post('/posts', async function(req, res) {
    res.send('ola mundo');
});

module.exports = router;
